<?php $__env->startSection('content'); ?>

<header class="main-header">
    <div class="d-flex align-items-center logo-box justify-content-center">
        <!-- Logo -->
        <a href="<?php echo e(route('home')); ?>" class="logo">
            <!-- logo-->
            <div class="logo-mini">
                <!-- <span class="light-logo"><img src="../images/logo-light.png" alt="logo"></span> -->
                <span class="dark-logo">SA</span>
            </div>
            <!-- logo-->
            <div class="logo-lg">
                <span class="dark-logo">Star Autocare</span>
                <!-- <span class="dark-logo"><img src="../images/logo-light-text.png" alt="logo"></span> -->
            </div>
        </a>
    </div>
    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top pl-10">
        <!-- Sidebar toggle button-->
        <div class="app-menu">
            <ul class="header-megamenu nav">
                <li class="btn-group nav-item">
                    <a href="#" class="waves-effect waves-light nav-link rounded push-btn" data-toggle="push-menu"
                        role="button">
                        <span class="icon-Align-left"><span class="path1"></span><span class="path2"></span><span
                                class="path3"></span></span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="navbar-custom-menu r-side">
            <ul class="nav navbar-nav">
                <li class="btn-group nav-item d-lg-inline-flex d-none">
                    <a href="#" data-provide="fullscreen" class="waves-effect waves-light nav-link rounded full-screen"
                        title="Full Screen">
                        <i class="icon-Expand-arrows"><span class="path1"></span><span class="path2"></span></i>
                    </a>
                </li>

                <!-- User Account-->
                <li class="dropdown user user-menu">
                    <a href="#" class="waves-effect waves-light dropdown-toggle" data-toggle="dropdown" title="User">
                        <i class="icon-User"><span class="path1"></span><span class="path2"></span></i>
                    </a>
                    <ul class="dropdown-menu animated flipInX">
                        <li class="user-body">
                            <a class="dropdown-item" href="#"><i class="ti-user text-muted mr-2"></i> Profile</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"><i
                                    class="ti-lock text-muted mr-2"></i> Logout</a>
                        </li>
                    </ul>
                </li>

            </ul>
        </div>
    </nav>
</header>

<aside class="main-sidebar">
    <!-- sidebar-->
    <section class="sidebar">

        <!-- sidebar menu-->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">Menu </li>

            <li>
                <a href="<?php echo e(route('dashboard')); ?>">
                    <i class="icon-Layout-4-blocks"><span class="path1"></span><span class="path2"></span></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('sessions.index')); ?>">
                    <i class="icon-Brush"><span class="path1"></span><span class="path2"></span></i>
                    <span>Sessions</span>
                </a>
            </li>

    </section>
    <div class="sidebar-footer">
        <!-- item-->
        <a href="javascript:void(0)" class="link" data-toggle="tooltip" title="" data-original-title="Settings"
            aria-describedby="tooltip92529"><span class="icon-Settings-2"></span></a>
        <!-- item-->
        <a href="<?php echo e(route('logout')); ?>" class="link" data-toggle="tooltip" title=""
            data-original-title="Logout"><span class="icon-Lock-overturning"><span class="path1"></span><span
                    class="path2"></span></span></a>
    </div>
</aside>

<div class="content-wrapper">
    <div class="container-full">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="d-flex align-items-center">
                <div class="mr-auto">
                    <h3 class="page-title">Sessions</h3>
                    <div class="d-inline-block align-items-center">
                        <nav>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
                                <li class="breadcrumb-item" aria-current="page">sessions</li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo e($vehicle->regNo); ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <?php if(!$tasks->isEmpty() && !$comments->isEmpty()): ?>
                <div class="send-btn">
    			  <div class="clearFix">
    				<div class="text-right pb-15">
    					<a id="email2" class="btn btn-warning" href="<?php echo e(route('session.sendMail', $session->id)); ?>"> <span><i class="fa fa-print"></i>Email Report</span> </a>
    				</div>
    			  </div>
    			</div>
                <?php endif; ?>
            </div>
            
        </div>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class=" col-lg-5 col-xl-4">
                    <div class="box box-widget widget-user">
                        <!-- Add the bg color to the header using any of the bg-* classes -->
                        <div class="widget-user-header bg-black"
                            style="/* background: url('../images/gallery/full/10.jpg') center center; */">
                            <h3 class="widget-user-username"><?php echo e($vehicle->regNo); ?></h3>
                            <h6 class="widget-user-desc"><?php echo e($vehicle->make); ?> <?php echo e($vehicle->model); ?></h6>
                        </div>

                    </div>
                    <div class="box">
                        <div class="box-body box-profile">
                            <div class="row">
                                <div class="col-12">
                                    <div>
                                        <p>Time in :<span class="text-gray pl-10"><?php echo e($session->created_at); ?></span>
                                        </p>
                                        <p>Time promised :<span class="text-gray pl-10"><?php echo e($session->timeOut); ?></span>
                                        </p>
                                        <p>Milleage :<span class="text-gray pl-10"><?php echo e($session->kilometers); ?></span>
                                        </p>
                                        <p>Fuel :&nbsp;<span class="badge badge-primary"><?php echo e($session->fuel); ?>%</span>
                                        </p>
                                        <p>Battery :<span class="text-gray pl-10"><?php echo e($session->battery); ?></span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>


                </div>

                <div class="col-12 col-lg-7 col-xl-8">
                    <div class="box box-solid box-warning">
                        <div class="box-header with-border">
                            <h4 class="box-title">Inspection</h4>

                            <ul class="box-controls pull-right">
                                <li><a class="box-btn-close" href="#"></a></li>
                                <li><a class="box-btn-slide" href="#"></a></li>
                                <li><a class="box-btn-fullscreen" href="#"></a></li>
                            </ul>
                        </div>
                        <div class="box-body p-0">
                            <ul class="todo-list">
                                <li class="p-15">
                                    <div class="box p-15 mb-0 d-block bb-2 border-danger">
                                        <span
                                            class="pull-right badge <?php if($inspection->rear_view_mirror == 'N/A'): ?> badge-warning <?php elseif($inspection->rear_view_mirror == 'Fix'): ?>  badge-danger <?php else: ?> badge-success <?php endif; ?>"><?php echo e($inspection->rear_view_mirror); ?></span>
                                        <span class="font-size-14 text-line">Rear_view_mirror </span>
                                    </div>
                                </li>
                                <li class="p-15">
                                    <div class="box p-15 mb-0 d-block bb-2 border-warning">
                                        <span
                                            class="pull-right badge <?php if($inspection->windshield == 'N/A'): ?> badge-warning <?php elseif($inspection->windshield == 'Fix'): ?>  badge-danger <?php else: ?> badge-success <?php endif; ?>"><?php echo e($inspection->windshield); ?></span>
                                        <span class="font-size-14 text-line">windshield </span>
                                    </div>
                                </li>
                                <li class="p-15">
                                    <div class="box p-15 mb-0 d-block bb-2 border-warning">
                                        <span
                                            class="pull-right badge <?php if($inspection->air_conditioning_operation == 'N/A'): ?> badge-warning <?php elseif($inspection->air_conditioning_operation == 'Fix'): ?>  badge-danger <?php else: ?> badge-success <?php endif; ?>"><?php echo e($inspection->air_conditioning_operation); ?></span>
                                        <span class="font-size-14 text-line">air_conditioning_operation</span>
                                    </div>
                                </li>
                                <li class="p-15">
                                    <div class="box p-15 mb-0 d-block bb-2 border-warning">
                                        <span
                                            class="pull-right badge <?php if($inspection->dash_board_instrumentation == 'N/A'): ?> badge-warning <?php elseif($inspection->dash_board_instrumentation == 'Fix'): ?>  badge-danger <?php else: ?> badge-success <?php endif; ?>"><?php echo e($inspection->dash_board_instrumentation); ?></span>
                                        <span class="font-size-14 text-line">dash_board_instrumentation </span>
                                    </div>
                                </li>
                                <li class="p-15">
                                    <div class="box p-15 mb-0 d-block bb-2 border-warning">
                                        <span
                                            class="pull-right badge <?php if($inspection->internal_lighting == 'N/A'): ?> badge-warning <?php elseif($inspection->internal_lighting == 'Fix'): ?>  badge-danger <?php else: ?> badge-success <?php endif; ?>"><?php echo e($inspection->internal_lighting); ?></span>
                                        <span class="font-size-14 text-line">internal_lighting</span>
                                    </div>
                                </li>
                                <li class="p-15">
                                    <div class="box p-15 mb-0 d-block bb-2 border-warning">
                                        <span
                                            class="pull-right badge <?php if($inspection->floor_carpeting == 'N/A'): ?> badge-warning <?php elseif($inspection->floor_carpeting == 'Fix'): ?>  badge-danger <?php else: ?> badge-success <?php endif; ?>"><?php echo e($inspection->floor_carpeting); ?></span>
                                        <span class="font-size-14 text-line">floor_carpeting</span>
                                    </div>
                                </li>
                                <li class="p-15">
                                    <div class="box p-15 mb-0 d-block bb-2 border-warning">
                                        <span
                                            class="pull-right badge <?php if($inspection->tyre_condition == 'N/A'): ?> badge-warning <?php elseif($inspection->tyre_condition == 'Fix'): ?>  badge-danger <?php else: ?> badge-success <?php endif; ?>"><?php echo e($inspection->tyre_condition); ?></span>
                                        <span class="font-size-14 text-line">tyre_condition</span>
                                    </div>
                                </li>
                                <li class="p-15">
                                    <div class="box p-15 mb-0 d-block bb-2 border-warning">
                                        <span
                                            class="pull-right badge <?php if($inspection->spear_wheel == 'N/A'): ?> badge-warning <?php elseif($inspection->spear_wheel == 'Fix'): ?>  badge-danger <?php else: ?> badge-success <?php endif; ?>"><?php echo e($inspection->spear_wheel); ?></span>
                                        <span class="font-size-14 text-line">spear_wheel</span>
                                    </div>
                                </li>
                                <li class="p-15">
                                    <div class="box p-15 mb-0 d-block bb-2 border-warning">
                                        <span
                                            class="pull-right badge <?php if($inspection->toolkit == 'N/A'): ?> badge-warning <?php elseif($inspection->toolkit == 'Fix'): ?>  badge-danger <?php else: ?> badge-success <?php endif; ?>"><?php echo e($inspection->toolkit); ?></span>
                                        <span class="font-size-14 text-line">toolkit</span>
                                    </div>
                                </li>
                                <li class="p-15">
                                    <div class="box p-15 mb-0 d-block bb-2 border-warning">
                                        <span
                                            class="pull-right badge <?php if($inspection->radio == 'N/A'): ?> badge-warning <?php elseif($inspection->radio == 'Fix'): ?>  badge-danger <?php else: ?> badge-success <?php endif; ?>"><?php echo e($inspection->radio); ?></span>
                                        <span class="font-size-14 text-line">radio</span>
                                    </div>
                                </li>

                            </ul>
                        </div>
                        <!-- /.box-body -->
                    </div>

                    <div class="box box-solid box-primary">
                        <div class="box-header with-border">
                            <h4 class="box-title">Tasks</h4>&nbsp; &nbsp;
                            <button type="button"
                                class="waves-effect waves-light btn btn-outline btn-rounded btn-warning mb-5 btn-sm"
                                data-toggle="modal" data-target="#taskModal">Add task</button>
                            <ul class="box-controls pull-right">
                                <li><a class="box-btn-close" href="#"></a></li>
                                <li><a class="box-btn-slide" href="#"></a></li>
                                <li><a class="box-btn-fullscreen" href="#"></a></li>
                            </ul>
                        </div>
                        <div class="box-body p-10">
                            <ul class="todo-list">
                                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="b-1 p-0 mb-15">
                                        <div class="position-relative p-20">
                                            <!-- drag handle -->
                                            <div class="handle handle2"></div>
                                            <form method="POST"
                                                action="<?php echo e(route('tasks.complete', $task->id)); ?>"
                                                style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <!-- checkbox -->
                                                <input type="hidden" name="completed" value="<?php echo e($task->checked); ?>">
                                                <input type="hidden" name="sessionId" value="<?php echo e($inspection->id); ?>">
                                                <input type="checkbox" id="basic_checkbox_<?php echo e($task->id); ?>"
                                                    class="filled-in" name="task" onChange="this.form.submit()" <?php if($task->checked ===
                                                1): ?>checked <?php echo e($task->todo); ?>

                                <?php endif; ?>>
                                                <label for="basic_checkbox_<?php echo e($task->id); ?>"
                                                    class="mb-0 h-15 ml-15"></label>
                                            </form>
                                            <!-- todo text -->
                                            <span class="text-line font-size-14"><?php if($task->checked ===
                                                1): ?><strike><?php echo e($task->todo); ?></strike><?php else: ?> <?php echo e($task->todo); ?>

                                <?php endif; ?></span>
                                <!-- General tools such as edit or delete-->
                                <div class="pull-right text-dark flexbox">
                                    <a href="#" data-toggle="modal" data-target="#editTaskModal" data-container="body"
                                        title="" data-original-title="Edit"><i class="fa fa-edit"></i></a>

                                    <!-- modal -->
                                    <div id="editTaskModal" class="modal fade" tabindex="-1" role="dialog"
                                        aria-labelledby="myModalLabel" style="display: none;" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="myModalLabel">Task
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-hidden="true">×</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form method="POST"
                                                        action="<?php echo e(route('tasks.update', $task->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <div class="box-body">

                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label>Edit Task</label>
                                                                        <input type="hidden" name="sessionId"
                                                                            value="<?php echo e($session->id); ?>"
                                                                            class="form-control"
                                                                            placeholder="e.g Replace oil filter">
                                                                        <input type="text" name="todo"
                                                                            value="<?php echo e($task->todo); ?>"
                                                                            class="form-control"
                                                                            placeholder="e.g Replace oil filter">
                                                                    </div>
                                                                </div>

                                                            </div>

                                                        </div>
                                                        <!-- /.box-body -->
                                                        <div class="box-footer">
                                                            <button type="button"
                                                                class="btn btn-rounded btn-primary btn-outline"
                                                                data-dismiss="modal">
                                                                Cancel
                                                            </button>&nbsp; &nbsp;
                                                            <button type="submit" href="inspection.php"
                                                                class="btn btn-rounded btn-warning btn-outline mr-1">
                                                                <i class="ti-save-alt"></i> Update
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>

                                            </div>
                                            <!-- /.modal-content -->
                                        </div>
                                        <!-- /.modal-dialog -->
                                    </div>

                                    <form action="<?php echo e(route('task.delete', $task->id)); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit"
                                            onclick="return confirm('Are you sure you want to delete this task?')"
                                            data-toggle="tooltip" data-container="body" title=""
                                            data-original-title="Remove"
                                            style="background:transparent;color: #a5b2cb;border:none;"><i
                                                class="fa fa-trash-o"></i></button>
                                    </form>
                                </div>
                                <div class="mt-5 ml-50 pl-5"><em><?php echo e($task->updated_at); ?></em></div>
                        </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <!-- /.box-body -->
                </div>

                <div class="box box-solid box-primary">
                    <div class="box-header with-border">
                        <h4 class="box-title">Comments</h4>&nbsp; &nbsp;
                        <button type="button"
                            class="waves-effect waves-light btn btn-outline btn-rounded btn-warning mb-5 btn-sm"
                            data-toggle="modal" data-target="#commentModal">Add comment</button>
                        <ul class="box-controls pull-right">
                            <li><a class="box-btn-close" href="#"></a></li>
                            <li><a class="box-btn-slide" href="#"></a></li>
                            <li><a class="box-btn-fullscreen" href="#"></a></li>
                        </ul>
                    </div>
                    <div class="box-body p-10">
                        <ul class="todo-list">
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="b-1 p-0 mb-15">
                                    <div class="position-relative p-20">
                                        <!-- todo text -->
                                        <span class="text-line font-size-14"><?php echo e($comment->comment); ?></span>
                                        <!-- General tools such as edit or delete-->
                                        <div class="pull-right text-dark flexbox">
                                            <a href="#" data-toggle="modal" data-target="#commentModalUpdate"
                                                data-container="body" title="" data-original-title="Edit"><i
                                                    class="fa fa-edit"></i></a>


                                            <!-- modal -->
                                            <div id="commentModalUpdate" class="modal fade" tabindex="-1" role="dialog"
                                                aria-labelledby="myModalLabel" style="display: none;"
                                                aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="myModalLabel">Add comments
                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-hidden="true">×</button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form method="POST"
                                                                action="<?php echo e(route('comments.update', $comment->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <div class="box-body">

                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label>Comments</label>
                                                                                <input type="text" name="comment"
                                                                                    class="form-control"
                                                                                    placeholder="Comment goes here">
                                                                            </div>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                                <!-- /.box-body -->
                                                                <div class="box-footer">
                                                                    <button type="button"
                                                                        class="btn btn-rounded btn-primary btn-outline"
                                                                        data-dismiss="modal">
                                                                        Cancel
                                                                    </button>&nbsp; &nbsp;
                                                                    <button type="submit" href="inspection.php"
                                                                        class="btn btn-rounded btn-warning btn-outline mr-1">
                                                                        <i class="ti-save-alt"></i> Save
                                                                    </button>
                                                                </div>
                                                            </form>
                                                        </div>

                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal-dialog -->
                                            </div>
                                            <form
                                                action="<?php echo e(route('comments.delete', $comment->id)); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit"
                                                    onclick="return confirm('Are you sure you want to delete this Comment?')"
                                                    data-toggle="tooltip" data-container="body" title=""
                                                    data-original-title="Remove"
                                                    style="background:transparent;color: #a5b2cb;border:none;"><i
                                                        class="fa fa-trash-o"></i></button>
                                            </form>
                                        </div>
                                        <div class="mt-5 ml-50 pl-5"><em><?php echo e($comment->updated_at); ?></em></div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>
                    <!-- /.box-body -->
                </div>

            </div>
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->

</div>
</div>

<footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
        <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
            <li class="nav-item">
                <a class="nav-link" href="javascript:void(0)">FAQ</a>
            </li>
        </ul>
    </div>
    &copy; 2021 <a href="http://starautocare.co.ke">Star Autocare</a>. All Rights Reserved.
</footer>


<!-- modal -->
<div id="taskModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="display: none;"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Add task</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('tasks.store', $inspection->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="box-body">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Task</label>
                                    <input type="hidden" name="sessionId" value="<?php echo e($session->id); ?>"
                                        class="form-control" placeholder="e.g Replace oil filter">
                                    <input type="text" name="todo" class="form-control">
                                </div>
                            </div>

                        </div>

                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button type="button" class="btn btn-rounded btn-primary btn-outline" data-dismiss="modal">
                            Cancel
                        </button>&nbsp; &nbsp;
                        <button type="submit" href="inspection.php"
                            class="btn btn-rounded btn-warning btn-outline mr-1">
                            <i class="ti-save-alt"></i> Save
                        </button>
                    </div>
                </form>
            </div>

        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<!-- modal -->
<div id="commentModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
    style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Add comments</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('comments.store', $inspection->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="box-body">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Comments</label>
                                    <input type="hidden" name="sessionId" value="<?php echo e($session->id); ?>"
                                        class="form-control">
                                    <input type="text" name="comment" class="form-control"
                                        placeholder="Comment goes here">
                                </div>
                            </div>

                        </div>

                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button type="button" class="btn btn-rounded btn-primary btn-outline" data-dismiss="modal">
                            Cancel
                        </button>&nbsp; &nbsp;
                        <button type="submit" href="inspection.php"
                            class="btn btn-rounded btn-warning btn-outline mr-1">
                            <i class="ti-save-alt"></i> Save
                        </button>
                    </div>
                </form>
            </div>

        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starcelg/public_html/resources/views/sessions/show.blade.php ENDPATH**/ ?>