<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="Absolute-Center is-Responsive">
                <div id="logo-container"></div>
                <div class="col-sm-12 col-md-10 col-md-offset-1">
                    <form method="POST" action="<?php echo e(route('loginSubmit')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input type="text" placeholder="Email" id="email" class="form-control" name="email" required
                                autofocus>
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>

                        </div>
                        <div class="form-group input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input type="password" placeholder="Password" id="password" class="form-control"
                                name="password" required>
                            <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group mb-3">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="remember"> Remember Me
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-dark btn-block">Signin</button>
                        </div>
                        <div class="form-group text-center">
                            <a href="<?php echo e(route('user.reset')); ?>">Forgot Password</a>
                        </div>
                        <!--<div class="alt-auth">-->
                        <!--    <p>Dont have an account? <a href="<?php echo e(route('register')); ?>">Sign up</a></p>-->
                        <!--</div>-->
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/starcelg/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>